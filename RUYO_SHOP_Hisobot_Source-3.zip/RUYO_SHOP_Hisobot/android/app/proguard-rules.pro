-keepclassmembers class tj.ruyo.shop.MainActivity$AndroidBridge {
    @android.webkit.JavascriptInterface <methods>;
}
