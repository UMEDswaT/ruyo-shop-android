(function (global) {
  'use strict';

  const DAY = 86400000;

  function num(v) {
    const n = Number(v);
    return Number.isFinite(n) ? n : 0;
  }

  function round2(v) {
    return Math.round((num(v) + Number.EPSILON) * 100) / 100;
  }

  function isoDate(d) {
    const x = d instanceof Date ? d : new Date(d);
    const y = x.getFullYear();
    const m = String(x.getMonth() + 1).padStart(2, '0');
    const day = String(x.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  }

  function normalizeDate(value) {
    if (!value) return '';
    if (/^\d{4}-\d{2}-\d{2}$/.test(String(value))) return String(value);
    return isoDate(new Date(value));
  }

  function inRange(date, start, end) {
    const d = normalizeDate(date);
    if (!d) return false;
    if (start && d < start) return false;
    if (end && d > end) return false;
    return true;
  }

  function period(type, now, customStart, customEnd) {
    const today = new Date(now || Date.now());
    today.setHours(0, 0, 0, 0);
    const end = new Date(today);
    let start = new Date(today);

    switch (type) {
      case 'today':
        break;
      case 'yesterday':
        start.setDate(start.getDate() - 1);
        end.setDate(end.getDate() - 1);
        break;
      case 'week': {
        const day = (start.getDay() + 6) % 7; // Monday=0
        start.setDate(start.getDate() - day);
        break;
      }
      case 'month':
        start = new Date(today.getFullYear(), today.getMonth(), 1);
        break;
      case 'year':
        start = new Date(today.getFullYear(), 0, 1);
        break;
      case 'custom':
        return {
          start: normalizeDate(customStart),
          end: normalizeDate(customEnd || customStart)
        };
      case 'all':
      default:
        return { start: '', end: '' };
    }
    return { start: isoDate(start), end: isoDate(end) };
  }

  function unitCost(product) {
    const qty = Math.max(1, num(product && product.purchasedQty));
    const base = num(product && product.purchasePrice);
    const allocated = (
      num(product && product.deliveryCost) +
      num(product && product.adCost) +
      num(product && product.otherCost)
    ) / qty;
    return round2(base + allocated);
  }

  function purchaseOutlay(product) {
    return round2(
      num(product && product.purchasedQty) * num(product && product.purchasePrice) +
      num(product && product.deliveryCost) +
      num(product && product.adCost) +
      num(product && product.otherCost)
    );
  }

  function soldQty(productId, sales, untilDate) {
    return (sales || [])
      .filter(s => Number(s.productId) === Number(productId) && (!untilDate || normalizeDate(s.date) <= normalizeDate(untilDate)))
      .reduce((a, s) => a + num(s.qty), 0);
  }

  function remainingQty(product, sales, untilDate) {
    if (!product) return 0;
    const purchaseDate = normalizeDate(product.purchaseDate);
    if (untilDate && purchaseDate && purchaseDate > normalizeDate(untilDate)) return 0;
    return Math.max(0, round2(num(product.purchasedQty) - soldQty(product.id, sales, untilDate)));
  }

  function saleMetrics(sale, product) {
    const qty = num(sale && sale.qty);
    const grossRevenue = qty * num(sale && sale.actualSalePrice);
    const discount = Math.max(0, num(sale && sale.discount));
    const revenue = Math.max(0, grossRevenue - discount);
    const cogs = unitCost(product) * qty;
    const delivery = Math.max(0, num(sale && sale.delivery));
    const profit = revenue - cogs - delivery;
    return {
      grossRevenue: round2(grossRevenue),
      discount: round2(discount),
      revenue: round2(revenue),
      cogs: round2(cogs),
      delivery: round2(delivery),
      profit: round2(profit)
    };
  }

  function inventoryValue(products, sales, untilDate) {
    return round2((products || []).reduce((sum, p) => {
      return sum + remainingQty(p, sales, untilDate) * unitCost(p);
    }, 0));
  }

  function productStats(products, sales, range) {
    const start = range && range.start;
    const end = range && range.end;
    return (products || []).map(p => {
      const psales = (sales || []).filter(s => Number(s.productId) === Number(p.id) && inRange(s.date, start, end));
      const sold = psales.reduce((a, s) => a + num(s.qty), 0);
      const revenue = psales.reduce((a, s) => a + saleMetrics(s, p).revenue, 0);
      const profit = psales.reduce((a, s) => a + saleMetrics(s, p).profit, 0);
      const lastSale = psales.map(s => normalizeDate(s.date)).sort().pop() || '';
      const ageDays = p.purchaseDate ? Math.max(0, Math.floor((Date.now() - new Date(p.purchaseDate + 'T00:00:00').getTime()) / DAY)) : 0;
      return {
        product: p,
        soldQty: round2(sold),
        revenue: round2(revenue),
        profit: round2(profit),
        remaining: remainingQty(p, sales),
        lastSale,
        ageDays
      };
    });
  }

  function dashboard(products, sales, expenses, range, lowStockThreshold) {
    const start = range && range.start;
    const end = range && range.end;
    const fsales = (sales || []).filter(s => inRange(s.date, start, end));
    const fexpenses = (expenses || []).filter(e => inRange(e.date, start, end));
    const fproducts = (products || []).filter(p => !start || !p.purchaseDate || inRange(p.purchaseDate, start, end));
    const pmap = new Map((products || []).map(p => [Number(p.id), p]));

    let salesRevenue = 0;
    let cogs = 0;
    let saleDelivery = 0;
    let discounts = 0;
    let soldUnits = 0;
    for (const s of fsales) {
      const p = pmap.get(Number(s.productId));
      if (!p) continue;
      const m = saleMetrics(s, p);
      salesRevenue += m.revenue;
      cogs += m.cogs;
      saleDelivery += m.delivery;
      discounts += m.discount;
      soldUnits += num(s.qty);
    }

    const extraExpenses = fexpenses.reduce((a, e) => a + Math.max(0, num(e.amount)), 0);
    const totalExpenses = cogs + saleDelivery + extraExpenses;
    const netProfit = salesRevenue - totalExpenses;
    const purchases = fproducts.reduce((a, p) => a + purchaseOutlay(p), 0);
    const threshold = Math.max(0, num(lowStockThreshold == null ? 5 : lowStockThreshold));
    const inventory = (products || []).map(p => ({ product: p, remaining: remainingQty(p, sales) }));
    const lowStock = inventory.filter(x => x.remaining > 0 && x.remaining <= threshold);
    const outOfStock = inventory.filter(x => x.remaining <= 0);
    const stats = productStats(products, sales, range);
    const topProfit = [...stats].sort((a, b) => b.profit - a.profit || b.soldQty - a.soldQty);
    const topSold = [...stats].sort((a, b) => b.soldQty - a.soldQty || b.profit - a.profit);
    const leastSold = [...stats].sort((a, b) => a.soldQty - b.soldQty || a.profit - b.profit);
    const stale = [...stats].filter(x => x.remaining > 0).sort((a, b) => b.ageDays - a.ageDays);

    return {
      salesRevenue: round2(salesRevenue),
      totalExpenses: round2(totalExpenses),
      netProfit: round2(netProfit),
      loss: round2(Math.max(0, -netProfit)),
      inventoryValue: inventoryValue(products, sales),
      purchaseOutlay: round2(purchases),
      extraExpenses: round2(extraExpenses),
      cogs: round2(cogs),
      saleDelivery: round2(saleDelivery),
      discounts: round2(discounts),
      soldUnits: round2(soldUnits),
      productCount: (products || []).length,
      salesCount: fsales.length,
      lowStock,
      outOfStock,
      topProfit,
      topSold,
      leastSold,
      stale,
      filteredSales: fsales,
      filteredExpenses: fexpenses
    };
  }

  function monthlyReport(products, sales, expenses, year, monthIndex, lowStockThreshold) {
    const start = isoDate(new Date(year, monthIndex, 1));
    const end = isoDate(new Date(year, monthIndex + 1, 0));
    const range = { start, end };
    const d = dashboard(products, sales, expenses, range, lowStockThreshold);
    const remainingAtEnd = round2((products || []).reduce((sum, p) => sum + remainingQty(p, sales, end), 0));
    const inventoryValueAtEnd = inventoryValue(products, sales, end);
    return {
      ...d,
      start,
      end,
      remainingUnitsAtEnd: remainingAtEnd,
      inventoryValueAtEnd,
      top5: d.topProfit.slice(0, 5)
    };
  }

  function validateProduct(product, sales, editingId) {
    const errors = [];
    if (!String(product.name || '').trim()) errors.push('name');
    if (num(product.purchasedQty) < 0) errors.push('purchasedQty');
    if (num(product.purchasePrice) < 0) errors.push('purchasePrice');
    if (num(product.salePrice) < 0) errors.push('salePrice');
    if (num(product.deliveryCost) < 0 || num(product.adCost) < 0 || num(product.otherCost) < 0) errors.push('costs');
    if (editingId != null) {
      const sold = soldQty(editingId, sales || []);
      if (num(product.purchasedQty) < sold) errors.push('purchasedQtyBelowSold');
    }
    return errors;
  }

  function validateSale(sale, product, sales, editingSale) {
    const errors = [];
    if (!product) errors.push('product');
    if (num(sale.qty) <= 0) errors.push('qty');
    if (num(sale.actualSalePrice) < 0) errors.push('price');
    if (num(sale.delivery) < 0 || num(sale.discount) < 0) errors.push('costs');
    if (product) {
      if (product.purchaseDate && sale.date && normalizeDate(sale.date) < normalizeDate(product.purchaseDate)) errors.push('dateBeforePurchase');
      let available = remainingQty(product, sales || []);
      if (editingSale && Number(editingSale.productId) === Number(product.id)) available += num(editingSale.qty);
      if (num(sale.qty) > available) errors.push('stock');
      if (num(sale.discount) > num(sale.qty) * num(sale.actualSalePrice)) errors.push('discount');
    }
    return errors;
  }

  function validateExpense(expense) {
    const errors = [];
    if (!String(expense.name || '').trim()) errors.push('name');
    if (num(expense.amount) <= 0) errors.push('amount');
    return errors;
  }

  const api = {
    num, round2, isoDate, normalizeDate, inRange, period, unitCost,
    purchaseOutlay, soldQty, remainingQty, saleMetrics, inventoryValue,
    productStats, dashboard, monthlyReport, validateProduct, validateSale,
    validateExpense
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  global.RuyoCore = api;
})(typeof window !== 'undefined' ? window : globalThis);
