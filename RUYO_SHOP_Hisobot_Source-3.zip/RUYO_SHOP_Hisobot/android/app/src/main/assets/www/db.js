(function (global) {
  'use strict';

  const DB_NAME = 'ruyo_shop_db';
  const DB_VERSION = 1;
  const STORES = ['products', 'sales', 'expenses'];

  function openDb() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains('products')) {
          const s = db.createObjectStore('products', { keyPath: 'id', autoIncrement: true });
          s.createIndex('name', 'name', { unique: false });
          s.createIndex('category', 'category', { unique: false });
          s.createIndex('purchaseDate', 'purchaseDate', { unique: false });
          s.createIndex('sku', 'sku', { unique: true });
        }
        if (!db.objectStoreNames.contains('sales')) {
          const s = db.createObjectStore('sales', { keyPath: 'id', autoIncrement: true });
          s.createIndex('productId', 'productId', { unique: false });
          s.createIndex('date', 'date', { unique: false });
        }
        if (!db.objectStoreNames.contains('expenses')) {
          const s = db.createObjectStore('expenses', { keyPath: 'id', autoIncrement: true });
          s.createIndex('date', 'date', { unique: false });
          s.createIndex('category', 'category', { unique: false });
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  async function tx(store, mode, fn) {
    const db = await openDb();
    return new Promise((resolve, reject) => {
      const t = db.transaction(store, mode);
      const os = t.objectStore(store);
      let result;
      try { result = fn(os); } catch (e) { reject(e); return; }
      t.oncomplete = () => resolve(result);
      t.onerror = () => reject(t.error);
      t.onabort = () => reject(t.error || new Error('Transaction aborted'));
    }).finally(() => db.close());
  }

  async function getAll(store) {
    const db = await openDb();
    return new Promise((resolve, reject) => {
      const t = db.transaction(store, 'readonly');
      const req = t.objectStore(store).getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
      t.oncomplete = () => db.close();
    });
  }

  async function get(store, id) {
    const db = await openDb();
    return new Promise((resolve, reject) => {
      const t = db.transaction(store, 'readonly');
      const req = t.objectStore(store).get(Number(id));
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
      t.oncomplete = () => db.close();
    });
  }

  async function add(store, value) {
    const db = await openDb();
    return new Promise((resolve, reject) => {
      const t = db.transaction(store, 'readwrite');
      const req = t.objectStore(store).add(value);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
      t.oncomplete = () => db.close();
    });
  }

  async function put(store, value) {
    const db = await openDb();
    return new Promise((resolve, reject) => {
      const t = db.transaction(store, 'readwrite');
      const req = t.objectStore(store).put(value);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
      t.oncomplete = () => db.close();
    });
  }

  async function remove(store, id) {
    return tx(store, 'readwrite', os => os.delete(Number(id)));
  }

  async function clear(store) {
    return tx(store, 'readwrite', os => os.clear());
  }

  async function replaceAll(data) {
    const db = await openDb();
    return new Promise((resolve, reject) => {
      const t = db.transaction(STORES, 'readwrite');
      for (const store of STORES) {
        const os = t.objectStore(store);
        os.clear();
        for (const row of (data[store] || [])) os.put(row);
      }
      t.oncomplete = () => { db.close(); resolve(true); };
      t.onerror = () => { db.close(); reject(t.error); };
      t.onabort = () => { db.close(); reject(t.error || new Error('Restore aborted')); };
    });
  }

  async function dump() {
    const [products, sales, expenses] = await Promise.all(STORES.map(getAll));
    return {
      schemaVersion: 1,
      app: 'RUYO SHOP — Ҳисобот ва Анбор',
      exportedAt: new Date().toISOString(),
      products,
      sales,
      expenses
    };
  }

  global.RuyoDB = { openDb, getAll, get, add, put, remove, clear, replaceAll, dump, STORES };
})(window);
