(function () {
  'use strict';

  const C = window.RuyoCore;
  const DB = window.RuyoDB;

  const i18n = {
    tg: {
      app:'RUYO SHOP', subtitle:'Ҳисобот ва Анбор', dashboard:'Асосӣ', products:'Молҳо', sales:'Фурӯш', expenses:'Хароҷот', inventory:'Анбор', reports:'Ҳисобот',
      today:'Имрӯз', yesterday:'Дирӯз', week:'Ҳафта', month:'Моҳ', year:'Соли ҷорӣ', all:'Ҳама', custom:'Давраи интихобшуда',
      totalSales:'Маблағи умумии фурӯш', netProfit:'Фоидаи соф', totalExpenses:'Хароҷоти умумӣ', inventoryValue:'Арзиши моли боқимонда',
      productCount:'Шумораи молҳо', salesCount:'Шумораи фурӯшҳо', lowStock:'Қариб тамомшуда', loss:'Зарар', top:'Рейтинги молҳо',
      addProduct:'Добавить товар', edit:'Изменить', delete:'Удалить', copy:'Копировать', noData:'Ҳоло маълумот нест', search:'Ҷустуҷӯ: ном, категория, ID, сана…',
      name:'Номи мол', category:'Категория', photo:'Сурат', sku:'Артикул / ID', purchasedQty:'Миқдори харидашуда', purchasePrice:'Нархи хариди 1 дона', salePrice:'Нархи фурӯши 1 дона', inboundDelivery:'Доставкаи воридотӣ (умумии партия)', adCost:'Рекламаи вобаста (умумӣ)', otherCost:'Дигар хароҷоти вобаста (умумӣ)', purchaseDate:'Санаи харид', supplier:'Таъминкунанда', note:'Эзоҳ', save:'Сабт кардан', cancel:'Бекор кардан',
      in:'Омад', sold:'Фурӯхта шуд', remaining:'Боқӣ монд', cost:'Себестоимость 1 дона', stockValue:'Арзиши боқимонда', outOfStock:'Тамомшуда',
      addSale:'Фурӯш илова кардан', product:'Мол', qty:'Миқдор', actualSalePrice:'Нархи воқеии фурӯш', date:'Сана', customer:'Номи харидор', phone:'Рақами телефон', payment:'Усули пардохт', delivery:'Доставкаи фурӯш', discount:'Тахфиф', saleDone:'Фурӯхта шуд',
      addExpense:'Расход илова кардан', amount:'Маблағ', expenseCategory:'Категория',
      monthly:'Ҳисоботи моҳона', purchasedAmount:'Моли харидашуда', soldAmount:'Маблағи фурӯш', soldUnits:'Миқдори фурӯхташуда', remainingUnits:'Миқдори боқимонда', grossProfit:'Фоида аз фурӯш пеш аз расходи иловагӣ', extraExpenses:'Расходи иловагӣ', top5:'TOP-5 моли беҳтарин',
      backup:'BACKUP', restore:'RESTORE', excel:'EXPORT EXCEL', pdf:'EXPORT PDF', settings:'Танзимот', language:'Забон', threshold:'Ҳадди «қариб тамом»',
      sureDelete:'Шумо боварӣ доред, ки ин маълумотро нест кардан мехоҳед?', productHasSales:'Ин мол фурӯш дорад. Агар нест кунед, ҳамаи фурӯшҳои вобаста ҳам нест мешаванд. Давом медиҳед?',
      stockError:'Миқдори фурӯш аз миқдори мавҷуд дар анбор зиёд аст.', invalid:'Маълумоти воридшуда нодуруст аст.', saved:'Маълумот сабт шуд.', deleted:'Маълумот нест шуд.', restored:'Backup бомуваффақият барқарор шуд.', restoreError:'Файли backup нодуруст аст.',
      topProfit:'Аз ҳама фоидаовар', topSold:'Аз ҳама зиёд фурӯхташуда', leastSold:'Аз ҳама кам фурӯхташуда', stale:'Муддати зиёд дар анбор',
      selectPeriod:'Давраро интихоб кунед', start:'Аз сана', end:'То сана', apply:'Татбиқ', currentInventory:'Анбори ҷорӣ', paymentCash:'Нақд', paymentCard:'Корти бонкӣ', other:'Дигар',
      accountingNote:'Доставка, реклама ва дигар хароҷоти вобаста ҳамчун хароҷоти умумии партия ворид шуда, ба ҳар дона мутаносиб тақсим мешаванд.',
      backupNote:'Backup ҳамаи молҳо, фурӯшҳо, хароҷот ва суратҳои сабтшударо нигоҳ медорад.', editQtyError:'Миқдори харидашуда аз миқдори аллакай фурӯхташуда кам шуда наметавонад.',
      noStock:'Дар анбор барои фурӯш мол нест.', profit:'Фоида', revenue:'Даромад', expense:'Расход', monthLabel:'Моҳ', from:'аз', to:'то'
    },
    ru: {
      app:'RUYO SHOP', subtitle:'Учёт и склад', dashboard:'Главная', products:'Товары', sales:'Продажи', expenses:'Расходы', inventory:'Склад', reports:'Отчёты',
      today:'Сегодня', yesterday:'Вчера', week:'Неделя', month:'Месяц', year:'Текущий год', all:'Все', custom:'Выбранный период',
      totalSales:'Общая сумма продаж', netProfit:'Чистая прибыль', totalExpenses:'Общие расходы', inventoryValue:'Стоимость остатка',
      productCount:'Количество товаров', salesCount:'Количество продаж', lowStock:'Почти закончились', loss:'Убыток', top:'Рейтинг товаров',
      addProduct:'Добавить товар', edit:'Изменить', delete:'Удалить', copy:'Копировать', noData:'Данных пока нет', search:'Поиск: название, категория, ID, дата…',
      name:'Название товара', category:'Категория', photo:'Фото', sku:'Артикул / ID', purchasedQty:'Закупленное количество', purchasePrice:'Цена закупки 1 шт.', salePrice:'Цена продажи 1 шт.', inboundDelivery:'Доставка закупки (на всю партию)', adCost:'Реклама товара (на всю партию)', otherCost:'Прочие связанные расходы (на всю партию)', purchaseDate:'Дата закупки', supplier:'Поставщик', note:'Примечание', save:'Сохранить', cancel:'Отмена',
      in:'Приход', sold:'Продано', remaining:'Остаток', cost:'Себестоимость 1 шт.', stockValue:'Стоимость остатка', outOfStock:'Закончились',
      addSale:'Добавить продажу', product:'Товар', qty:'Количество', actualSalePrice:'Фактическая цена продажи', date:'Дата', customer:'Имя покупателя', phone:'Телефон', payment:'Способ оплаты', delivery:'Доставка продажи', discount:'Скидка', saleDone:'Продано',
      addExpense:'Добавить расход', amount:'Сумма', expenseCategory:'Категория',
      monthly:'Месячный отчёт', purchasedAmount:'Закуплено товара', soldAmount:'Сумма продаж', soldUnits:'Продано единиц', remainingUnits:'Остаток единиц', grossProfit:'Прибыль от продаж до доп. расходов', extraExpenses:'Доп. расходы', top5:'TOP-5 товаров',
      backup:'BACKUP', restore:'RESTORE', excel:'EXPORT EXCEL', pdf:'EXPORT PDF', settings:'Настройки', language:'Язык', threshold:'Порог «почти закончился»',
      sureDelete:'Вы уверены, что хотите удалить эти данные?', productHasSales:'У товара есть продажи. При удалении будут удалены и связанные продажи. Продолжить?',
      stockError:'Количество продажи превышает остаток на складе.', invalid:'Введены некорректные данные.', saved:'Данные сохранены.', deleted:'Данные удалены.', restored:'Backup успешно восстановлен.', restoreError:'Некорректный файл backup.',
      topProfit:'Самый прибыльный', topSold:'Самый продаваемый', leastSold:'Самый малопродаваемый', stale:'Долго лежит на складе',
      selectPeriod:'Выберите период', start:'С даты', end:'По дату', apply:'Применить', currentInventory:'Текущий склад', paymentCash:'Наличные', paymentCard:'Банковская карта', other:'Другое',
      accountingNote:'Доставка, реклама и прочие связанные расходы вводятся на всю партию и автоматически распределяются на каждую единицу.',
      backupNote:'Backup сохраняет товары, продажи, расходы и сохранённые фотографии.', editQtyError:'Закупленное количество не может быть меньше уже проданного.',
      noStock:'На складе нет товара для продажи.', profit:'Прибыль', revenue:'Выручка', expense:'Расход', monthLabel:'Месяц', from:'с', to:'по'
    }
  };

  const state = {
    lang: localStorage.getItem('ruyo_lang') || 'tg',
    page: 'dashboard',
    filter: localStorage.getItem('ruyo_filter') || 'month',
    customStart: localStorage.getItem('ruyo_custom_start') || '',
    customEnd: localStorage.getItem('ruyo_custom_end') || '',
    lowStockThreshold: Number(localStorage.getItem('ruyo_low_stock') || 5),
    products: [], sales: [], expenses: [], search: ''
  };

  const $ = s => document.querySelector(s);
  const $$ = s => Array.from(document.querySelectorAll(s));
  function t(k){ return (i18n[state.lang] && i18n[state.lang][k]) || k; }
  function h(v){ return String(v == null ? '' : v).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c])); }
  function money(v){ return `${C.round2(v).toLocaleString(state.lang === 'ru' ? 'ru-RU' : 'tg-TJ', {maximumFractionDigits:2})} сомонӣ`; }
  function dateFmt(v){ if(!v) return '—'; const [y,m,d]=String(v).split('-'); return `${d}.${m}.${y}`; }
  function toast(msg){ const el=$('#toast'); el.textContent=msg; el.classList.remove('hidden'); clearTimeout(toast.timer); toast.timer=setTimeout(()=>el.classList.add('hidden'),2200); }
  function currentRange(){ return C.period(state.filter, new Date(), state.customStart, state.customEnd); }
  function prodById(id){ return state.products.find(p=>Number(p.id)===Number(id)); }

  async function loadData(){
    [state.products,state.sales,state.expenses] = await Promise.all([DB.getAll('products'),DB.getAll('sales'),DB.getAll('expenses')]);
    state.products.sort((a,b)=>Number(b.id)-Number(a.id));
    state.sales.sort((a,b)=>String(b.date).localeCompare(String(a.date)) || Number(b.id)-Number(a.id));
    state.expenses.sort((a,b)=>String(b.date).localeCompare(String(a.date)) || Number(b.id)-Number(a.id));
  }

  function renderShell(){
    $('#brand-title').textContent=t('app');
    $('#brand-subtitle').textContent=t('subtitle');
    $('#lang-btn').textContent=state.lang==='tg'?'RU':'TJ';
    const labels={dashboard:'dashboard',products:'products',sales:'sales',expenses:'expenses',inventory:'inventory',reports:'reports'};
    $$('.nav-item').forEach(el=>{ el.classList.toggle('active',el.dataset.page===state.page); el.querySelector('.nav-label').textContent=t(labels[el.dataset.page]); });
    renderFilters();
  }

  function renderFilters(){
    const holder=$('#filterbar');
    const items=[['today','today'],['yesterday','yesterday'],['week','week'],['month','month'],['year','year'],['all','all'],['custom','custom']];
    holder.innerHTML=items.map(([id,k])=>`<button class="chip ${state.filter===id?'active':''}" data-filter="${id}">${h(t(k))}</button>`).join('');
  }

  function render(){
    renderShell();
    const main=$('#main');
    if(state.page==='dashboard') main.innerHTML=renderDashboard();
    if(state.page==='products') main.innerHTML=renderProducts();
    if(state.page==='sales') main.innerHTML=renderSales();
    if(state.page==='expenses') main.innerHTML=renderExpenses();
    if(state.page==='inventory') main.innerHTML=renderInventory();
    if(state.page==='reports') main.innerHTML=renderReports();
    bindPageEvents();
  }

  function metric(label,value,cls=''){
    return `<div class="card metric ${cls}"><div class="label">${h(label)}</div><div class="value">${h(value)}</div></div>`;
  }

  function insightCard(label,item,valueFn){
    if(!item) return `<div class="card insight"><div class="label">${h(label)}</div><div class="title">—</div></div>`;
    return `<div class="card insight"><div class="label">${h(label)}</div><div class="title">${h(item.product.name)}</div><div class="sub">${h(item.product.sku||'')} · ${h(valueFn(item))}</div></div>`;
  }

  function renderDashboard(){
    const d=C.dashboard(state.products,state.sales,state.expenses,currentRange(),state.lowStockThreshold);
    const top=d.topProfit.slice(0,3);
    return `
      <div class="grid">
        ${metric(t('totalSales'),money(d.salesRevenue),'gold')}
        ${metric(t('netProfit'),money(d.netProfit),d.netProfit>=0?'good':'bad')}
        ${metric(t('totalExpenses'),money(d.totalExpenses))}
        ${metric(t('inventoryValue'),money(d.inventoryValue),'gold')}
        ${metric(t('productCount'),String(d.productCount))}
        ${metric(t('salesCount'),String(d.salesCount))}
        ${metric(t('lowStock'),String(d.lowStock.length),d.lowStock.length?'bad':'')}
        ${metric(t('loss'),money(d.loss),d.loss>0?'bad':'')}
      </div>
      <div class="section-title"><h2>${h(t('top'))}</h2><span>${h(rangeText())}</span></div>
      <div class="list">
        ${top.length?top.map((x,i)=>rankRow(x,i+1)).join(''):`<div class="empty">${h(t('noData'))}</div>`}
      </div>
      <div class="analysis-grid">
        ${insightCard(t('topProfit'),d.topProfit[0],x=>money(x.profit))}
        ${insightCard(t('topSold'),d.topSold[0],x=>`${x.soldQty} ${t('sold')}`)}
        ${insightCard(t('leastSold'),d.leastSold[0],x=>`${x.soldQty} ${t('sold')}`)}
        ${insightCard(t('stale'),d.stale[0],x=>`${x.ageDays} ${state.lang==='ru'?'дн.':'рӯз'}`)}
      </div>
      <div class="section-title"><h2>${h(t('currentInventory'))}</h2><span>${state.products.length}</span></div>
      <div class="card">
        <div class="kpi-line"><span>${h(t('lowStock'))}</span><b>${d.lowStock.length}</b></div>
        <div class="kpi-line"><span>${h(t('outOfStock'))}</span><b>${d.outOfStock.length}</b></div>
        <div class="kpi-line"><span>${h(t('stockValue'))}</span><b class="money">${money(d.inventoryValue)}</b></div>
      </div>`;
  }

  function rankRow(x,n){
    return `<div class="row-card rank"><div class="rank-no">TOP ${n}</div><div class="rank-info"><div class="title">${h(x.product.name)}</div><div class="sub">${h(x.product.sku||'')} · ${t('sold')}: ${x.soldQty} · ${t('remaining')}: ${x.remaining}</div></div><div class="profit">${money(x.profit)}</div></div>`;
  }

  function renderProducts(){
    const q=state.search.trim().toLowerCase();
    const list=state.products.filter(p=>!q || [p.name,p.category,p.sku,p.purchaseDate].some(v=>String(v||'').toLowerCase().includes(q)));
    return `<div class="search"><input id="search-input" value="${h(state.search)}" placeholder="${h(t('search'))}"><button class="btn primary" id="add-product">＋</button></div>
      <div class="notice"><strong>i</strong> ${h(t('accountingNote'))}</div>
      <div class="section-title"><h2>${h(t('products'))}</h2><span>${list.length}</span></div>
      <div class="list">${list.length?list.map(productRow).join(''):`<div class="empty">${h(t('noData'))}</div>`}</div>`;
  }

  function productRow(p){
    const sold=C.soldQty(p.id,state.sales), rem=C.remainingQty(p,state.sales), uc=C.unitCost(p);
    const img=p.imageData?`<img class="thumb" src="${p.imageData}" alt="">`:`<div class="thumb placeholder">RS</div>`;
    return `<div class="row-card">${img}<div class="grow"><div class="title">${h(p.name)}</div><div class="sub">${h(p.sku||'')} · ${h(p.category||'—')}</div><div class="sub">${t('in')}: <b>${p.purchasedQty}</b> · ${t('sold')}: <b>${sold}</b> · ${t('remaining')}: <b>${rem}</b></div><div class="sub">${t('cost')}: ${money(uc)} · ${t('salePrice')}: ${money(p.salePrice)}</div><div class="row-actions"><button class="btn small" data-edit-product="${p.id}">${t('edit')}</button><button class="btn small" data-copy-product="${p.id}">${t('copy')}</button><button class="btn small danger" data-delete-product="${p.id}">${t('delete')}</button></div></div></div>`;
  }

  function renderSales(){
    const r=currentRange();
    const list=state.sales.filter(s=>C.inRange(s.date,r.start,r.end));
    return `<div class="section-title"><h2>${h(t('sales'))}</h2><button class="btn primary small" id="add-sale">＋ ${h(t('addSale'))}</button></div>
      <div class="list">${list.length?list.map(saleRow).join(''):`<div class="empty">${h(t('noData'))}</div>`}</div>`;
  }

  function saleRow(s){
    const p=prodById(s.productId); if(!p) return '';
    const m=C.saleMetrics(s,p);
    return `<div class="row-card"><div class="grow"><div class="title">${h(p.name)}</div><div class="sub">${dateFmt(s.date)} · ${s.qty} × ${money(s.actualSalePrice)} · ${h(s.paymentMethod||'—')}</div><div class="sub">${t('revenue')}: <b>${money(m.revenue)}</b> · ${t('profit')}: <b style="color:${m.profit>=0?'var(--green)':'var(--red)'}">${money(m.profit)}</b></div><div class="row-actions"><button class="btn small" data-edit-sale="${s.id}">${t('edit')}</button><button class="btn small danger" data-delete-sale="${s.id}">${t('delete')}</button></div></div></div>`;
  }

  function renderExpenses(){
    const r=currentRange();
    const list=state.expenses.filter(e=>C.inRange(e.date,r.start,r.end));
    const total=list.reduce((a,e)=>a+C.num(e.amount),0);
    return `<div class="section-title"><h2>${h(t('expenses'))}</h2><button class="btn primary small" id="add-expense">＋ ${h(t('addExpense'))}</button></div>
      <div class="card metric"><div class="label">${h(t('totalExpenses'))}</div><div class="value">${money(total)}</div></div>
      <div class="section-title"><h2>${h(t('expenses'))}</h2><span>${list.length}</span></div>
      <div class="list">${list.length?list.map(expenseRow).join(''):`<div class="empty">${h(t('noData'))}</div>`}</div>`;
  }

  function expenseRow(e){
    return `<div class="row-card"><div class="grow"><div class="title">${h(e.name)}</div><div class="sub">${dateFmt(e.date)} · ${h(e.category||'—')}</div><div class="money">${money(e.amount)}</div><div class="row-actions"><button class="btn small" data-edit-expense="${e.id}">${t('edit')}</button><button class="btn small danger" data-delete-expense="${e.id}">${t('delete')}</button></div></div></div>`;
  }

  function renderInventory(){
    const rows=state.products.map(p=>({p,rem:C.remainingQty(p,state.sales),sold:C.soldQty(p.id,state.sales),uc:C.unitCost(p)})).sort((a,b)=>a.rem-b.rem);
    return `<div class="section-title"><h2>${h(t('inventory'))}</h2><span>${rows.length}</span></div><div class="list">${rows.length?rows.map(x=>{
      const status=x.rem<=0?`<span class="badge red">${t('outOfStock')}</span>`:x.rem<=state.lowStockThreshold?`<span class="badge gold">${t('lowStock')}</span>`:`<span class="badge green">OK</span>`;
      return `<div class="row-card"><div class="grow"><div class="title">${h(x.p.name)} ${status}</div><div class="sub">${h(x.p.sku||'')} · ${t('in')}: ${x.p.purchasedQty} · ${t('sold')}: ${x.sold} · ${t('remaining')}: <b>${x.rem}</b></div><div class="sub">${t('stockValue')}: <b class="money">${money(x.rem*x.uc)}</b></div></div></div>`;
    }).join(''):`<div class="empty">${h(t('noData'))}</div>`}</div>`;
  }

  function renderReports(){
    const now=new Date();
    const defaultMonth=`${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}`;
    const selected=localStorage.getItem('ruyo_report_month')||defaultMonth;
    const [y,m]=selected.split('-').map(Number);
    const r=C.monthlyReport(state.products,state.sales,state.expenses,y,m-1,state.lowStockThreshold);
    const grossBeforeExtra=C.round2(r.salesRevenue-r.cogs-r.saleDelivery);
    return `<div class="section-title"><h2>${h(t('monthly'))}</h2></div>
      <div class="form-group"><label>${h(t('monthLabel'))}</label><input id="report-month" type="month" value="${h(selected)}"></div>
      <div class="report-box"><div class="report-grid">
        ${reportItem(t('purchasedAmount'),money(r.purchaseOutlay))}
        ${reportItem(t('soldAmount'),money(r.salesRevenue))}
        ${reportItem(t('soldUnits'),String(r.soldUnits))}
        ${reportItem(t('remainingUnits'),String(r.remainingUnitsAtEnd))}
        ${reportItem(t('totalExpenses'),money(r.totalExpenses))}
        ${reportItem(t('grossProfit'),money(grossBeforeExtra))}
        ${reportItem(t('netProfit'),money(r.netProfit))}
        ${reportItem(t('loss'),money(r.loss))}
        ${reportItem(t('inventoryValue'),money(r.inventoryValueAtEnd))}
      </div><div class="hr"></div><b>${h(t('top5'))}</b><div class="list" style="margin-top:10px">${r.top5.length?r.top5.map((x,i)=>rankRow(x,i+1)).join(''):`<div class="empty">${h(t('noData'))}</div>`}</div></div>
      <div class="section-title"><h2>Backup / Export</h2></div>
      <div class="two"><button class="btn primary" id="backup-btn">${t('backup')}</button><button class="btn" id="restore-btn">${t('restore')}</button><button class="btn" id="excel-btn">${t('excel')}</button><button class="btn" id="pdf-btn">${t('pdf')}</button></div>
      <input class="hidden" id="restore-file" type="file" accept="application/json,.json">
      <div class="notice" style="margin-top:10px">${h(t('backupNote'))}</div>
      <div class="section-title"><h2>${h(t('settings'))}</h2></div>
      <div class="card"><div class="form-group"><label>${h(t('threshold'))}</label><input id="threshold-input" type="number" min="0" step="1" value="${state.lowStockThreshold}"></div></div>`;
  }

  function reportItem(label,value){ return `<div class="report-item"><small>${h(label)}</small><b>${h(value)}</b></div>`; }
  function rangeText(){ const r=currentRange(); return r.start?`${dateFmt(r.start)} — ${dateFmt(r.end)}`:t('all'); }

  function bindPageEvents(){
    const si=$('#search-input'); if(si) si.addEventListener('input',e=>{state.search=e.target.value;render();$('#search-input')?.focus();});
    $('#add-product')?.addEventListener('click',()=>openProductForm());
    $('#add-sale')?.addEventListener('click',()=>openSaleForm());
    $('#add-expense')?.addEventListener('click',()=>openExpenseForm());
    $$('[data-edit-product]').forEach(b=>b.onclick=()=>openProductForm(prodById(b.dataset.editProduct)));
    $$('[data-copy-product]').forEach(b=>b.onclick=()=>copyProduct(Number(b.dataset.copyProduct)));
    $$('[data-delete-product]').forEach(b=>b.onclick=()=>deleteProduct(Number(b.dataset.deleteProduct)));
    $$('[data-edit-sale]').forEach(b=>b.onclick=()=>openSaleForm(state.sales.find(s=>Number(s.id)===Number(b.dataset.editSale))));
    $$('[data-delete-sale]').forEach(b=>b.onclick=()=>deleteSimple('sales',Number(b.dataset.deleteSale)));
    $$('[data-edit-expense]').forEach(b=>b.onclick=()=>openExpenseForm(state.expenses.find(e=>Number(e.id)===Number(b.dataset.editExpense))));
    $$('[data-delete-expense]').forEach(b=>b.onclick=()=>deleteSimple('expenses',Number(b.dataset.deleteExpense)));
    $('#report-month')?.addEventListener('change',e=>{localStorage.setItem('ruyo_report_month',e.target.value);render();});
    $('#backup-btn')?.addEventListener('click',backup);
    $('#restore-btn')?.addEventListener('click',()=>$('#restore-file').click());
    $('#restore-file')?.addEventListener('change',restoreFromFile);
    $('#excel-btn')?.addEventListener('click',exportExcel);
    $('#pdf-btn')?.addEventListener('click',exportPdf);
    $('#threshold-input')?.addEventListener('change',e=>{state.lowStockThreshold=Math.max(0,Number(e.target.value)||0);localStorage.setItem('ruyo_low_stock',state.lowStockThreshold);render();});
  }

  function openModal(title,body){
    const modal=$('#modal');
    modal.innerHTML=`<div class="modal-sheet"><div class="modal-head"><h3>${h(title)}</h3><button class="icon-btn" id="modal-close">✕</button></div>${body}</div>`;
    modal.classList.remove('hidden');
    $('#modal-close').onclick=closeModal;
    modal.onclick=e=>{ if(e.target===modal) closeModal(); };
  }
  function closeModal(){ $('#modal').classList.add('hidden'); $('#modal').innerHTML=''; }

  function openProductForm(p){
    const edit=!!p; const v=p||{};
    openModal(edit?t('edit'):t('addProduct'),`<form id="product-form"><div class="form-grid">
      ${field('name',t('name'),v.name,'text',true)} ${field('category',t('category'),v.category)}
      ${field('purchasedQty',t('purchasedQty'),v.purchasedQty??0,'number',true,'min="0" step="1"')} ${field('purchasePrice',t('purchasePrice'),v.purchasePrice??0,'number',true,'min="0" step="0.01"')}
      ${field('salePrice',t('salePrice'),v.salePrice??0,'number',true,'min="0" step="0.01"')} ${field('deliveryCost',t('inboundDelivery'),v.deliveryCost??0,'number',false,'min="0" step="0.01"')}
      ${field('adCost',t('adCost'),v.adCost??0,'number',false,'min="0" step="0.01"')} ${field('otherCost',t('otherCost'),v.otherCost??0,'number',false,'min="0" step="0.01"')}
      ${field('purchaseDate',t('purchaseDate'),v.purchaseDate||C.isoDate(new Date()),'date',true)} ${field('supplier',t('supplier'),v.supplier)}
      <div class="form-group"><label>${h(t('photo'))}</label><input name="photo" type="file" accept="image/*"></div>
      <div class="form-group"><label>${h(t('sku'))}</label><input value="${h(v.sku||'AUTO')}" disabled></div>
    </div><div class="form-group"><label>${h(t('note'))}</label><textarea name="note">${h(v.note||'')}</textarea></div><div class="notice">${h(t('accountingNote'))}</div><div class="form-actions"><button type="button" class="btn" id="form-cancel">${t('cancel')}</button><button type="submit" class="btn primary">${t('save')}</button></div></form>`);
    $('#form-cancel').onclick=closeModal;
    $('#product-form').onsubmit=async e=>{
      e.preventDefault(); const fd=new FormData(e.currentTarget);
      const obj={
        name:String(fd.get('name')||'').trim(),category:String(fd.get('category')||'').trim(),purchasedQty:C.num(fd.get('purchasedQty')),purchasePrice:C.num(fd.get('purchasePrice')),salePrice:C.num(fd.get('salePrice')),deliveryCost:C.num(fd.get('deliveryCost')),adCost:C.num(fd.get('adCost')),otherCost:C.num(fd.get('otherCost')),purchaseDate:String(fd.get('purchaseDate')||''),supplier:String(fd.get('supplier')||'').trim(),note:String(fd.get('note')||'').trim(),imageData:v.imageData||'',createdAt:v.createdAt||new Date().toISOString(),updatedAt:new Date().toISOString()
      };
      const errs=C.validateProduct(obj,state.sales,edit?p.id:null); if(errs.length){ alert(errs.includes('purchasedQtyBelowSold')?t('editQtyError'):t('invalid')); return; }
      const file=fd.get('photo'); if(file && file.size) obj.imageData=await resizeImage(file,900,0.82);
      if(edit){ obj.id=p.id; obj.sku=p.sku; await DB.put('products',obj); }
      else { const id=await DB.add('products',obj); obj.id=id; obj.sku=`RUYO-${String(id).padStart(6,'0')}`; await DB.put('products',obj); }
      closeModal(); await loadData(); render(); toast(t('saved'));
    };
  }

  function field(name,label,value,type='text',required=false,extra=''){
    return `<div class="form-group"><label>${h(label)}</label><input name="${name}" type="${type}" value="${h(value??'')}" ${required?'required':''} ${extra}></div>`;
  }

  async function copyProduct(id){
    const p=prodById(id); if(!p) return;
    const c={...p}; delete c.id; delete c.sku; c.name=`${p.name} — copy`; c.createdAt=new Date().toISOString(); c.updatedAt=c.createdAt;
    const nid=await DB.add('products',c); c.id=nid; c.sku=`RUYO-${String(nid).padStart(6,'0')}`; await DB.put('products',c);
    await loadData(); render(); toast(t('saved'));
  }

  async function deleteProduct(id){
    if(!confirm(t('sureDelete'))) return;
    const linked=state.sales.filter(s=>Number(s.productId)===Number(id));
    if(linked.length && !confirm(t('productHasSales'))) return;
    for(const s of linked) await DB.remove('sales',s.id);
    await DB.remove('products',id); await loadData(); render(); toast(t('deleted'));
  }

  function openSaleForm(s){
    if(!state.products.length){ alert(t('noStock')); return; }
    const edit=!!s, v=s||{};
    const opts=state.products.map(p=>`<option value="${p.id}" ${Number(v.productId)===Number(p.id)?'selected':''}>${h(p.name)} (${t('remaining')}: ${C.remainingQty(p,state.sales)+(edit&&Number(v.productId)===Number(p.id)?C.num(v.qty):0)})</option>`).join('');
    const paymentValues=state.lang==='ru'?['Наличные','Банковская карта','Alif','DC City','Amonatbank','Другое']:['Нақд','Корти бонкӣ','Alif','DC City','Amonatbank','Дигар'];
    const paymentOpts=paymentValues.map(x=>`<option ${v.paymentMethod===x?'selected':''}>${h(x)}</option>`).join('');
    openModal(edit?t('edit'):t('addSale'),`<form id="sale-form"><div class="form-grid">
      <div class="form-group"><label>${t('product')}</label><select name="productId" id="sale-product">${opts}</select></div>
      ${field('qty',t('qty'),v.qty??1,'number',true,'min="1" step="1"')}
      ${field('actualSalePrice',t('actualSalePrice'),v.actualSalePrice??'', 'number',true,'min="0" step="0.01"')}
      ${field('date',t('date'),v.date||C.isoDate(new Date()),'date',true)}
      ${field('customerName',t('customer'),v.customerName)} ${field('phone',t('phone'),v.phone,'tel')}
      <div class="form-group"><label>${t('payment')}</label><select name="paymentMethod">${paymentOpts}</select></div>
      ${field('delivery',t('delivery'),v.delivery??0,'number',false,'min="0" step="0.01"')}
      ${field('discount',t('discount'),v.discount??0,'number',false,'min="0" step="0.01"')}
    </div><div class="form-group"><label>${t('note')}</label><textarea name="note">${h(v.note||'')}</textarea></div><div class="form-actions"><button type="button" class="btn" id="form-cancel">${t('cancel')}</button><button type="submit" class="btn primary">${t('saleDone')}</button></div></form>`);
    $('#form-cancel').onclick=closeModal;
    const setDefaultPrice=()=>{const p=prodById(Number($('#sale-product').value));const input=$('[name="actualSalePrice"]');if(!edit||!input.value) input.value=p?p.salePrice:0;}; setDefaultPrice(); $('#sale-product').onchange=setDefaultPrice;
    $('#sale-form').onsubmit=async e=>{
      e.preventDefault(); const fd=new FormData(e.currentTarget); const obj={productId:Number(fd.get('productId')),qty:C.num(fd.get('qty')),actualSalePrice:C.num(fd.get('actualSalePrice')),date:String(fd.get('date')||''),customerName:String(fd.get('customerName')||'').trim(),phone:String(fd.get('phone')||'').trim(),paymentMethod:String(fd.get('paymentMethod')||''),delivery:C.num(fd.get('delivery')),discount:C.num(fd.get('discount')),note:String(fd.get('note')||'').trim(),createdAt:v.createdAt||new Date().toISOString(),updatedAt:new Date().toISOString()};
      const p=prodById(obj.productId); const errs=C.validateSale(obj,p,state.sales,edit?s:null); if(errs.length){ alert(errs.includes('stock')?t('stockError'):t('invalid')); return; }
      if(edit){obj.id=s.id;await DB.put('sales',obj);}else await DB.add('sales',obj);
      closeModal();await loadData();render();toast(t('saved'));
    };
  }

  function openExpenseForm(e){
    const edit=!!e,v=e||{}; const cats=state.lang==='ru'?['Реклама','Доставка','Такси','Бензин','Упаковка','Комиссия банка','Аренда','Интернет','Зарплата','Другие расходы']:['Реклама','Доставка','Такси','Бензин','Упаковка','Комиссияи бонк','Иҷора','Интернет','Маош','Дигар хароҷот'];
    openModal(edit?t('edit'):t('addExpense'),`<form id="expense-form"><div class="form-grid">
      ${field('name',t('name'),v.name,'text',true)} ${field('amount',t('amount'),v.amount??0,'number',true,'min="0.01" step="0.01"')}
      ${field('date',t('date'),v.date||C.isoDate(new Date()),'date',true)}<div class="form-group"><label>${t('expenseCategory')}</label><select name="category">${cats.map(x=>`<option ${v.category===x?'selected':''}>${h(x)}</option>`).join('')}</select></div>
    </div><div class="form-group"><label>${t('note')}</label><textarea name="note">${h(v.note||'')}</textarea></div><div class="form-actions"><button type="button" class="btn" id="form-cancel">${t('cancel')}</button><button type="submit" class="btn primary">${t('save')}</button></div></form>`);
    $('#form-cancel').onclick=closeModal;
    $('#expense-form').onsubmit=async ev=>{ev.preventDefault();const fd=new FormData(ev.currentTarget);const obj={name:String(fd.get('name')||'').trim(),amount:C.num(fd.get('amount')),date:String(fd.get('date')||''),category:String(fd.get('category')||''),note:String(fd.get('note')||'').trim(),createdAt:v.createdAt||new Date().toISOString(),updatedAt:new Date().toISOString()};if(C.validateExpense(obj).length){alert(t('invalid'));return;}if(edit){obj.id=e.id;await DB.put('expenses',obj);}else await DB.add('expenses',obj);closeModal();await loadData();render();toast(t('saved'));};
  }

  async function deleteSimple(store,id){ if(!confirm(t('sureDelete')))return;await DB.remove(store,id);await loadData();render();toast(t('deleted')); }

  function openCustomPeriod(){
    openModal(t('selectPeriod'),`<div class="form-grid">${field('customStart',t('start'),state.customStart||C.isoDate(new Date()),'date',true)}${field('customEnd',t('end'),state.customEnd||C.isoDate(new Date()),'date',true)}</div><div class="form-actions"><button class="btn" id="form-cancel">${t('cancel')}</button><button class="btn primary" id="apply-period">${t('apply')}</button></div>`);
    $('#form-cancel').onclick=closeModal; $('#apply-period').onclick=()=>{const a=$('[name="customStart"]').value,b=$('[name="customEnd"]').value;if(!a||!b||a>b){alert(t('invalid'));return;}state.customStart=a;state.customEnd=b;state.filter='custom';localStorage.setItem('ruyo_custom_start',a);localStorage.setItem('ruyo_custom_end',b);localStorage.setItem('ruyo_filter','custom');closeModal();render();};
  }

  async function resizeImage(file,maxSide,quality){
    return new Promise((resolve,reject)=>{const reader=new FileReader();reader.onerror=reject;reader.onload=()=>{const img=new Image();img.onerror=reject;img.onload=()=>{let w=img.width,h=img.height;const scale=Math.min(1,maxSide/Math.max(w,h));w=Math.round(w*scale);h=Math.round(h*scale);const c=document.createElement('canvas');c.width=w;c.height=h;c.getContext('2d').drawImage(img,0,0,w,h);resolve(c.toDataURL('image/jpeg',quality));};img.src=reader.result;};reader.readAsDataURL(file);});
  }

  async function backup(){ const data=await DB.dump(); const text=JSON.stringify(data,null,2); await saveText(`RUYO_SHOP_BACKUP_${C.isoDate(new Date())}.json`,'application/json',text); }

  async function restoreFromFile(e){
    const file=e.target.files&&e.target.files[0]; if(!file)return;
    try{const text=await file.text();const data=JSON.parse(text);if(data.schemaVersion!==1||!Array.isArray(data.products)||!Array.isArray(data.sales)||!Array.isArray(data.expenses))throw new Error('schema');if(!confirm(t('sureDelete')))return;await DB.replaceAll(data);await loadData();render();toast(t('restored'));}catch(err){console.error(err);alert(t('restoreError'));}finally{e.target.value='';}
  }

  function xml(v){return String(v==null?'':v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
  function xlCell(v,type){return `<Cell><Data ss:Type="${type||'String'}">${xml(v)}</Data></Cell>`;}
  function xlSheet(name,headers,rows){return `<Worksheet ss:Name="${xml(name)}"><Table><Row>${headers.map(x=>xlCell(x)).join('')}</Row>${rows.map(r=>`<Row>${r.map(v=>xlCell(v,typeof v==='number'?'Number':'String')).join('')}</Row>`).join('')}</Table></Worksheet>`;}
  async function exportExcel(){
    const products=state.products.map(p=>[p.sku||'',p.name||'',p.category||'',C.num(p.purchasedQty),C.num(p.purchasePrice),C.num(p.salePrice),C.unitCost(p),C.soldQty(p.id,state.sales),C.remainingQty(p,state.sales),C.remainingQty(p,state.sales)*C.unitCost(p),p.purchaseDate||'',p.supplier||'',p.note||'']);
    const sales=state.sales.map(s=>{const p=prodById(s.productId),m=p?C.saleMetrics(s,p):{revenue:0,cogs:0,profit:0};return [s.id,p?p.sku:'',p?p.name:'',s.date||'',C.num(s.qty),C.num(s.actualSalePrice),C.num(s.discount),C.num(s.delivery),m.revenue,m.cogs,m.profit,s.paymentMethod||'',s.customerName||'',s.phone||'',s.note||''];});
    const expenses=state.expenses.map(e=>[e.id,e.date||'',e.name||'',e.category||'',C.num(e.amount),e.note||'']);
    const book=`<?xml version="1.0"?><Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">${xlSheet('Products',['SKU','Name','Category','Purchased Qty','Purchase Price','Sale Price','Unit Cost','Sold Qty','Remaining Qty','Stock Value','Purchase Date','Supplier','Note'],products)}${xlSheet('Sales',['ID','SKU','Product','Date','Qty','Actual Price','Discount','Delivery','Revenue','COGS','Profit','Payment','Customer','Phone','Note'],sales)}${xlSheet('Expenses',['ID','Date','Name','Category','Amount','Note'],expenses)}</Workbook>`;
    await saveText(`RUYO_SHOP_${C.isoDate(new Date())}.xls`,'application/vnd.ms-excel',book);
  }

  function exportPdf(){
    if(window.Android && typeof window.Android.printPage==='function'){window.Android.printPage();return;}
    window.print();
  }

  async function saveText(filename,mime,text){
    if(window.Android && typeof window.Android.saveBase64==='function'){
      const bytes=new TextEncoder().encode(text); let bin=''; const chunk=0x8000; for(let i=0;i<bytes.length;i+=chunk) bin+=String.fromCharCode.apply(null,bytes.subarray(i,i+chunk)); window.Android.saveBase64(filename,mime,btoa(bin)); return;
    }
    const blob=new Blob([text],{type:mime}); const url=URL.createObjectURL(blob); const a=document.createElement('a');a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500);
  }

  document.addEventListener('click',e=>{
    const nav=e.target.closest('.nav-item'); if(nav){state.page=nav.dataset.page;state.search='';render();return;}
    const chip=e.target.closest('[data-filter]'); if(chip){const f=chip.dataset.filter;if(f==='custom'){openCustomPeriod();return;}state.filter=f;localStorage.setItem('ruyo_filter',f);render();return;}
  });

  $('#lang-btn').onclick=()=>{state.lang=state.lang==='tg'?'ru':'tg';localStorage.setItem('ruyo_lang',state.lang);render();};

  async function init(){
    try{await loadData();render();if('serviceWorker' in navigator && location.protocol.startsWith('http')) navigator.serviceWorker.register('./sw.js').catch(()=>{});}catch(e){console.error(e);document.querySelector('#main').innerHTML=`<div class="empty">Database error: ${h(e.message)}</div>`;}
  }

  init();
})();
