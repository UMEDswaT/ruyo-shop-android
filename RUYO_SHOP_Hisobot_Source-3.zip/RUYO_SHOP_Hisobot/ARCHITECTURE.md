# RUYO SHOP — Architecture

## Layers
1. **UI / presentation** — `web/index.html`, `web/styles.css`, `web/app.js`
2. **Business rules** — `web/core.js` (pure accounting and inventory functions)
3. **Persistence adapter** — `web/db.js` (IndexedDB CRUD, backup, atomic restore)
4. **Android shell** — `MainActivity.java` (standalone WebView, secure local origin, file picker, export bridge, Android print/PDF)
5. **Build/CI** — Gradle Android project + `.github/workflows/android-apk.yml`

## Offline-first model
No API or internet request is required for normal operation. Android serves bundled assets from the virtual HTTPS origin `https://ruyo.local` via `shouldInterceptRequest`. IndexedDB and local settings persist under that application origin.

## Accounting formulas
- Lot linked cost per unit = `(deliveryCost + adCost + otherCost) / purchasedQty`
- Unit cost = `purchasePrice + lot linked cost per unit`
- Sale revenue = `qty × actualSalePrice - discount`
- COGS = `qty × unitCost`
- Sale profit = `sale revenue - COGS - outbound sale delivery`
- Total expenses = `COGS + outbound sale delivery + extra expenses`
- Net profit = `sales revenue - total expenses`
- Loss = `max(0, -net profit)`
- Current inventory value = `remainingQty × unitCost`

## Data integrity
- Sale quantity must be > 0.
- Sale cannot exceed available stock.
- Editing a sale temporarily returns its old quantity before stock validation.
- Purchased quantity cannot be edited below already-sold quantity.
- Sale date cannot be earlier than product purchase date.
- Negative costs are rejected.
- Discount cannot exceed gross sale amount.
- Product delete asks for confirmation; if linked sales exist, a second warning is required and dependent sales are removed with the product.

## Cloud-sync extension point
`db.js` is the persistence boundary. Future synchronization can be added by introducing a sync adapter while retaining `core.js` calculations and UI contracts.
