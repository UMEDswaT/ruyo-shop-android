# Database schema

## products
- id INTEGER auto
- sku TEXT unique, auto format RUYO-000001
- name TEXT required
- category TEXT
- imageData TEXT (compressed JPEG data URL)
- purchasedQty NUMBER >= 0
- purchasePrice NUMBER >= 0
- salePrice NUMBER >= 0
- deliveryCost NUMBER >= 0 (batch total)
- adCost NUMBER >= 0 (batch total)
- otherCost NUMBER >= 0 (batch total)
- purchaseDate DATE
- supplier TEXT
- note TEXT
- createdAt DATETIME
- updatedAt DATETIME

## sales
- id INTEGER auto
- productId INTEGER relation -> products.id
- qty NUMBER > 0
- actualSalePrice NUMBER >= 0
- date DATE
- customerName TEXT optional
- phone TEXT optional
- paymentMethod TEXT
- delivery NUMBER >= 0
- discount NUMBER >= 0 and <= gross sale value
- note TEXT
- createdAt DATETIME
- updatedAt DATETIME

## expenses
- id INTEGER auto
- name TEXT required
- amount NUMBER > 0
- date DATE
- category TEXT
- note TEXT
- createdAt DATETIME
- updatedAt DATETIME

## Derived values
- soldQty(product) = SUM(sales.qty WHERE productId)
- remainingQty = purchasedQty - soldQty
- unitCost = purchasePrice + (deliveryCost + adCost + otherCost) / purchasedQty
- stockValue = remainingQty * unitCost
- saleRevenue = qty * actualSalePrice - discount
- saleCOGS = qty * unitCost
- saleProfit = saleRevenue - saleCOGS - sale.delivery
