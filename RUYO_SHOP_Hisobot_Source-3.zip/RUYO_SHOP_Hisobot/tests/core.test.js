const assert = require('assert');
const C = require('../web/core.js');

const products=[
  {id:1,name:'A',purchasedQty:100,purchasePrice:50,salePrice:80,deliveryCost:500,adCost:300,otherCost:200,purchaseDate:'2026-09-01'},
  {id:2,name:'B',purchasedQty:20,purchasePrice:100,salePrice:140,deliveryCost:0,adCost:0,otherCost:0,purchaseDate:'2026-08-10'}
];
const sales=[
  {id:1,productId:1,qty:10,actualSalePrice:80,discount:0,delivery:50,date:'2026-09-05'},
  {id:2,productId:1,qty:5,actualSalePrice:75,discount:25,delivery:0,date:'2026-09-07'},
  {id:3,productId:2,qty:2,actualSalePrice:140,discount:0,delivery:0,date:'2026-08-20'}
];
const expenses=[{id:1,name:'Taxi',amount:100,date:'2026-09-06'}];

assert.strictEqual(C.unitCost(products[0]),60); // 50 + 1000/100
assert.strictEqual(C.purchaseOutlay(products[0]),6000);
assert.strictEqual(C.soldQty(1,sales),15);
assert.strictEqual(C.remainingQty(products[0],sales),85);

let m=C.saleMetrics(sales[0],products[0]);
assert.deepStrictEqual(m,{grossRevenue:800,discount:0,revenue:800,cogs:600,delivery:50,profit:150});

m=C.saleMetrics(sales[1],products[0]);
assert.strictEqual(m.revenue,350); // 5*75-25
assert.strictEqual(m.cogs,300);
assert.strictEqual(m.profit,50);

const d=C.dashboard(products,sales,expenses,{start:'2026-09-01',end:'2026-09-30'},5);
assert.strictEqual(d.salesRevenue,1150);
assert.strictEqual(d.cogs,900);
assert.strictEqual(d.saleDelivery,50);
assert.strictEqual(d.extraExpenses,100);
assert.strictEqual(d.totalExpenses,1050);
assert.strictEqual(d.netProfit,100);
assert.strictEqual(d.loss,0);
assert.strictEqual(d.soldUnits,15);
assert.strictEqual(d.salesCount,2);
assert.strictEqual(d.productCount,2);
assert.strictEqual(d.inventoryValue,6900);


const rep=C.monthlyReport(products,sales,expenses,2026,8,5); // September
assert.strictEqual(rep.start,'2026-09-01');
assert.strictEqual(rep.end,'2026-09-30');
assert.strictEqual(rep.purchaseOutlay,6000); // only product A purchased in Sep
assert.strictEqual(rep.remainingUnitsAtEnd,103);
assert.strictEqual(rep.inventoryValueAtEnd,6900);

// sale validation: cannot oversell
assert(C.validateSale({productId:1,qty:86,actualSalePrice:80,delivery:0,discount:0},products[0],sales,null).includes('stock'));
// editing same sale can reuse its old quantity
assert(!C.validateSale({productId:1,qty:90,actualSalePrice:80,delivery:0,discount:0},products[0],sales,sales[0]).includes('stock'));
// product quantity cannot be reduced below sold
assert(C.validateProduct({...products[0],purchasedQty:14},sales,1).includes('purchasedQtyBelowSold'));
// negative amounts rejected
assert(C.validateExpense({name:'x',amount:-1}).includes('amount'));

// period boundaries
const pr=C.period('month',new Date('2026-09-10T12:00:00'));
assert.deepStrictEqual(pr,{start:'2026-09-01',end:'2026-09-10'});
assert(C.inRange('2026-09-10','2026-09-01','2026-09-10'));
assert(!C.inRange('2026-08-31','2026-09-01','2026-09-10'));

console.log('All core tests passed');

// Extra regression tests
assert(C.validateSale({productId:1,qty:1,actualSalePrice:80,delivery:0,discount:81,date:'2026-09-05'},products[0],sales,null).includes('discount'));
assert(C.validateSale({productId:1,qty:1,actualSalePrice:80,delivery:0,discount:0,date:'2026-08-31'},products[0],sales,null).includes('dateBeforePurchase'));
assert.strictEqual(C.remainingQty(products[0],sales,'2026-08-31'),0); // before purchase
assert.strictEqual(C.remainingQty(products[0],sales,'2026-09-06'),90); // only first sale by that date
const custom=C.period('custom',new Date('2026-09-10T12:00:00'),'2026-09-02','2026-09-08');
assert.deepStrictEqual(custom,{start:'2026-09-02',end:'2026-09-08'});
const ranking=C.dashboard(products,sales,expenses,{start:'',end:''},5);
assert.strictEqual(ranking.topProfit[0].product.id,1);
assert.strictEqual(ranking.topSold[0].product.id,1);
assert.strictEqual(ranking.leastSold[0].product.id,2);
// Negative net profit is exposed as loss
const lossDash=C.dashboard([products[1]],[],[{id:9,name:'Rent',amount:500,date:'2026-09-01'}],{start:'2026-09-01',end:'2026-09-30'},5);
assert.strictEqual(lossDash.netProfit,-500);
assert.strictEqual(lossDash.loss,500);
// Zero/invalid product-linked costs never produce NaN/Infinity
assert.strictEqual(C.unitCost({purchasedQty:0,purchasePrice:10,deliveryCost:0,adCost:0,otherCost:0}),10);
assert(Number.isFinite(C.inventoryValue([{id:99,purchasedQty:0,purchasePrice:10}],[])));

console.log('Extended regression tests passed');
