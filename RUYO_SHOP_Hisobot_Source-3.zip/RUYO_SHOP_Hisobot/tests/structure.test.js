const fs=require('fs');
const path=require('path');
const assert=require('assert');
const root=path.resolve(__dirname,'..');
const app=fs.readFileSync(path.join(root,'web/app.js'),'utf8');
const html=fs.readFileSync(path.join(root,'web/index.html'),'utf8');
const db=fs.readFileSync(path.join(root,'web/db.js'),'utf8');
const java=fs.readFileSync(path.join(root,'android/app/src/main/java/tj/ruyo/shop/MainActivity.java'),'utf8');

for(const id of ['main','filterbar','lang-btn','modal','toast']) assert(html.includes(`id="${id}"`),`Missing ${id}`);
for(const page of ['dashboard','products','sales','expenses','inventory','reports']) assert(html.includes(`data-page="${page}"`),`Missing nav ${page}`);
for(const fn of ['openProductForm','openSaleForm','openExpenseForm','deleteProduct','deleteSimple','backup','restoreFromFile','exportExcel','exportPdf']) assert(app.includes(`function ${fn}`)||app.includes(`async function ${fn}`),`Missing function ${fn}`);
for(const store of ['products','sales','expenses']) assert(db.includes(`'${store}'`),`Missing DB store ${store}`);
for(const method of ['saveBase64','printPage','shouldInterceptRequest','onShowFileChooser']) assert(java.includes(method),`Missing Android integration ${method}`);
assert(java.includes('https://ruyo.local/index.html'),'Android app must load bundled UI without Chrome');
assert(java.includes('ACTION_CREATE_DOCUMENT'),'Exports must use Android document picker');

// Bundled web assets must be byte-identical to development web assets.
for(const f of ['index.html','styles.css','core.js','db.js','app.js','manifest.webmanifest','sw.js']){
  const a=fs.readFileSync(path.join(root,'web',f));
  const b=fs.readFileSync(path.join(root,'android/app/src/main/assets/www',f));
  assert(a.equals(b),`Android bundled asset out of sync: ${f}`);
}
console.log('Structure/integration tests passed');
