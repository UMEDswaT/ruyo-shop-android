# RUYO SHOP — QA Report

## Automated checks passed
- Unit cost allocation across a purchase lot
- Purchase outlay
- Sold quantity and remaining stock
- Sale revenue, COGS, delivery, discount and profit
- Dashboard totals and net profit/loss
- Monthly report boundaries and month-end stock
- Current and historical inventory values
- Oversell rejection
- Sale-edit stock reconciliation
- Product edit cannot reduce quantity below already sold
- Invalid/negative expense rejection
- Discount greater than gross sale rejection
- Sale-before-purchase-date rejection
- Today/month/custom period boundaries
- TOP profit / TOP sales / least-sales ranking ordering
- Android bundled assets match source web assets
- Required CRUD/export/backup functions are present
- Android bridge has file save, PDF print and file chooser hooks
- Android manifest/style/icon XML parse successfully
- JavaScript syntax checks pass

Commands:
- `node tests/core.test.js`
- `node tests/structure.test.js`
- `node --check web/core.js web/db.js web/app.js web/sw.js` (run individually)

## Build validation status
An actual APK binary was **not compiled in this execution environment** because Android SDK / build-tools / Gradle are not installed and outbound package downloads are unavailable. The project includes a GitHub Actions build workflow to compile the APK in a standard Android CI environment.

This means business logic and source structure were tested here, but device-level installation/runtime testing of the compiled APK still requires an Android build runner.
