# RUYO SHOP — Ҳисобот ва Анбор

Production-oriented offline-first mobile shop accounting application.

## Core modules
- Dashboard
- Products CRUD + copy product + photo
- Sales CRUD + stock validation
- Expenses CRUD
- Inventory derived from purchases and sales
- Date filters: today, yesterday, week, month, year, all, custom
- Product ranking TOP 1/2/3 by profit
- Monthly reports + TOP-5
- Backup / Restore JSON
- Export Excel (.xls XML workbook)
- Export PDF via Android print framework
- Tajik / Russian UI
- TJS currency

## Accounting model
Unit cost = purchasePricePerUnit + (inboundDelivery + productAdvertising + otherRelatedCosts) / purchasedQty

Sale revenue = qty * actualSalePrice - discount

Sale profit = sale revenue - qty * unit cost - sale delivery

Net profit = sales revenue - COGS - sale delivery - extra expenses

Current inventory value = remaining qty * unit cost

## Data persistence
The embedded app uses IndexedDB on a secure local virtual origin (`https://ruyo.local`) inside Android WebView. Data remains on the device between app restarts. Backup/Restore gives an explicit portable copy.

## Android structure
- Application ID: `tj.ruyo.shop`
- minSdk: 23
- targetSdk: 35
- compileSdk: 35
- Android WebView wrapper serves bundled assets locally; it does not require Chrome for daily use.

## Build
This repository is configured for Gradle / Android Gradle Plugin 8.7.3. A machine or CI runner with Android SDK 35 and Gradle wrapper/tooling can build:

`./gradlew assembleDebug`

Output will normally be under:
`android/app/build/outputs/apk/debug/`

The current ChatGPT execution environment did not contain Android SDK/Gradle and external SDK downloads were blocked, so an APK binary could not be produced locally in this run.

## Tests
Run core accounting tests:

`node tests/core.test.js`

Covered cases include:
- unit cost allocation
- purchase outlay
- stock remaining
- sale revenue/profit
- dashboard net profit
- monthly report boundaries
- overselling prevention
- editing sale stock recovery
- preventing product quantity below sold amount
- negative expense validation
- date filtering

## Important implementation behavior
Inventory is derived from immutable purchase quantity minus sales rows. This means deleting/editing a sale automatically restores/recalculates stock instead of manually mutating a second stock counter.
